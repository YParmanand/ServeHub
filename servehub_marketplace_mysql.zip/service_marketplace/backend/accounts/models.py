"""
Accounts Models
- Custom User extending AbstractUser with role-based access
- Profile for both providers and receivers
"""

from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator, MaxValueValidator


class User(AbstractUser):
    """
    Custom User model with role selection.
    user_type determines provider vs receiver capabilities.
    """
    USER_TYPE_CHOICES = (
        ('provider', 'Service Provider'),
        ('receiver', 'Service Receiver'),
    )

    email = models.EmailField(unique=True)
    user_type = models.CharField(max_length=10, choices=USER_TYPE_CHOICES, default='receiver')
    phone = models.CharField(max_length=20, blank=True)
    is_verified = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'user_type']

    class Meta:
        db_table = 'users'

    def __str__(self):
        return f"{self.email} ({self.user_type})"

    @property
    def is_provider(self):
        return self.user_type == 'provider'

    @property
    def is_receiver(self):
        return self.user_type == 'receiver'


class ProviderProfile(models.Model):
    """
    Extended profile for service providers.
    Contains professional details, skills, experience.
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='provider_profile')
    bio = models.TextField(blank=True)
    profile_image = models.ImageField(upload_to='profiles/', blank=True, null=True)
    skills = models.TextField(blank=True, help_text="Comma-separated skills")
    experience_years = models.PositiveIntegerField(default=0)
    hourly_rate = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    city = models.CharField(max_length=100, blank=True)
    state = models.CharField(max_length=100, blank=True)
    country = models.CharField(max_length=100, blank=True)
    is_available = models.BooleanField(default=True)
    rating = models.DecimalField(
        max_digits=3, decimal_places=2, default=0,
        validators=[MinValueValidator(0), MaxValueValidator(5)]
    )
    total_reviews = models.PositiveIntegerField(default=0)
    total_bookings = models.PositiveIntegerField(default=0)
    linkedin_url = models.URLField(blank=True)
    portfolio_url = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'provider_profiles'

    def __str__(self):
        return f"Provider: {self.user.get_full_name() or self.user.email}"

    def update_rating(self):
        """Recalculate average rating from all reviews."""
        from reviews.models import Review
        reviews = Review.objects.filter(service__provider=self.user)
        if reviews.exists():
            total = sum(r.rating for r in reviews)
            self.rating = total / reviews.count()
            self.total_reviews = reviews.count()
            self.save(update_fields=['rating', 'total_reviews'])


class ReceiverProfile(models.Model):
    """
    Profile for service receivers/customers.
    Contains personal info and address.
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='receiver_profile')
    bio = models.TextField(blank=True)
    profile_image = models.ImageField(upload_to='profiles/', blank=True, null=True)
    address = models.TextField(blank=True)
    city = models.CharField(max_length=100, blank=True)
    state = models.CharField(max_length=100, blank=True)
    country = models.CharField(max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'receiver_profiles'

    def __str__(self):
        return f"Receiver: {self.user.get_full_name() or self.user.email}"
