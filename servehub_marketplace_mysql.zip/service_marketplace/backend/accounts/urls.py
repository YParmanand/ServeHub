from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from . import views

urlpatterns = [
    path('register/', views.RegisterView.as_view(), name='register'),
    path('login/', views.LoginView.as_view(), name='login'),
    path('logout/', views.LogoutView.as_view(), name='logout'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('me/', views.MeView.as_view(), name='me'),
    path('provider-profile/', views.ProviderProfileView.as_view(), name='provider-profile'),
    path('receiver-profile/', views.ReceiverProfileView.as_view(), name='receiver-profile'),
    path('providers/<int:pk>/', views.PublicProviderProfileView.as_view(), name='public-provider'),
    path('change-password/', views.ChangePasswordView.as_view(), name='change-password'),
]
