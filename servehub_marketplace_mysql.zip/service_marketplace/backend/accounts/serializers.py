"""
Accounts Serializers
Handles user registration, login, and profile management
"""

from rest_framework import serializers
from django.contrib.auth.password_validation import validate_password
from django.db import transaction
from .models import User, ProviderProfile, ReceiverProfile


class ProviderProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProviderProfile
        fields = [
            'id', 'bio', 'profile_image', 'skills', 'experience_years',
            'hourly_rate', 'city', 'state', 'country', 'is_available',
            'rating', 'total_reviews', 'total_bookings',
            'linkedin_url', 'portfolio_url'
        ]
        read_only_fields = ['rating', 'total_reviews', 'total_bookings']


class ReceiverProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReceiverProfile
        fields = ['id', 'bio', 'profile_image', 'address', 'city', 'state', 'country']


class UserRegistrationSerializer(serializers.ModelSerializer):
    """Serializer for user registration with profile creation."""
    password = serializers.CharField(write_only=True, validators=[validate_password])
    password_confirm = serializers.CharField(write_only=True)
    # Provider fields (optional)
    skills = serializers.CharField(required=False, allow_blank=True)
    experience_years = serializers.IntegerField(required=False, default=0)
    hourly_rate = serializers.DecimalField(required=False, max_digits=10, decimal_places=2, default=0)
    city = serializers.CharField(required=False, allow_blank=True)
    state = serializers.CharField(required=False, allow_blank=True)
    country = serializers.CharField(required=False, allow_blank=True)
    bio = serializers.CharField(required=False, allow_blank=True)

    class Meta:
        model = User
        fields = [
            'id', 'email', 'username', 'first_name', 'last_name',
            'phone', 'user_type', 'password', 'password_confirm',
            'skills', 'experience_years', 'hourly_rate',
            'city', 'state', 'country', 'bio'
        ]

    def validate(self, attrs):
        if attrs['password'] != attrs.pop('password_confirm'):
            raise serializers.ValidationError({'password': 'Passwords do not match.'})
        return attrs

    @transaction.atomic
    def create(self, validated_data):
        # Extract profile fields
        profile_fields = {
            'skills': validated_data.pop('skills', ''),
            'experience_years': validated_data.pop('experience_years', 0),
            'hourly_rate': validated_data.pop('hourly_rate', 0),
            'city': validated_data.pop('city', ''),
            'state': validated_data.pop('state', ''),
            'country': validated_data.pop('country', ''),
            'bio': validated_data.pop('bio', ''),
        }

        user = User.objects.create_user(**validated_data)

        # Create appropriate profile based on user_type
        if user.user_type == 'provider':
            ProviderProfile.objects.create(user=user, **profile_fields)
        else:
            ReceiverProfile.objects.create(
                user=user,
                bio=profile_fields['bio'],
                city=profile_fields['city'],
                state=profile_fields['state'],
                country=profile_fields['country'],
            )
        return user


class UserSerializer(serializers.ModelSerializer):
    """Full user serializer with nested profile."""
    provider_profile = ProviderProfileSerializer(read_only=True)
    receiver_profile = ReceiverProfileSerializer(read_only=True)
    full_name = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            'id', 'email', 'username', 'first_name', 'last_name',
            'full_name', 'phone', 'user_type', 'is_verified',
            'provider_profile', 'receiver_profile', 'created_at'
        ]
        read_only_fields = ['email', 'user_type', 'is_verified', 'created_at']

    def get_full_name(self, obj):
        return obj.get_full_name() or obj.username


class UserUpdateSerializer(serializers.ModelSerializer):
    """Serializer for updating basic user info."""
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'phone']


class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True, validators=[validate_password])
    confirm_password = serializers.CharField(required=True)

    def validate(self, attrs):
        if attrs['new_password'] != attrs['confirm_password']:
            raise serializers.ValidationError({'new_password': 'Passwords do not match.'})
        return attrs
