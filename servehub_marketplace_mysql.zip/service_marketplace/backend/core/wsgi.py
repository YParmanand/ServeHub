"""
ServeHub — WSGI entry point for production servers (Gunicorn, uWSGI).
"""
import os
from django.core.wsgi import get_wsgi_application

# Uncomment if using PyMySQL instead of mysqlclient:
# import pymysql
# pymysql.install_as_MySQLdb()

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
application = get_wsgi_application()
