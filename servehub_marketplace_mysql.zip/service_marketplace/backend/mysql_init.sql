-- ================================================================
--  ServeHub Service Marketplace — MySQL Database Init Script
--  Run this ONCE before starting Django:
--    mysql -u root -pparma123 < mysql_init.sql
-- ================================================================

-- Create the database with utf8mb4 (supports emojis & all Unicode)
CREATE DATABASE IF NOT EXISTS service_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

-- Select it
USE service_db;

-- Verify
SELECT 'Database service_db created successfully.' AS status;
SELECT SCHEMA_NAME, DEFAULT_CHARACTER_SET_NAME, DEFAULT_COLLATION_NAME
  FROM information_schema.SCHEMATA
  WHERE SCHEMA_NAME = 'service_db';

-- ================================================================
-- Django will create all tables automatically via:
--   python manage.py migrate
-- ================================================================
--
-- Expected tables after migration:
--   users                    (accounts_user)
--   provider_profiles        (accounts_providerprofile)
--   receiver_profiles        (accounts_receiverprofile)
--   service_categories       (services_servicecategory)
--   services                 (services_service)
--   bookings                 (bookings_booking)
--   reviews                  (reviews_review)
--   token_blacklist_*        (JWT token blacklist)
--   django_*                 (Django internals)
--   auth_*                   (Django auth)
-- ================================================================
