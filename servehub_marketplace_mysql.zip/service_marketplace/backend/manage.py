#!/usr/bin/env python
"""
ServeHub Service Marketplace
Django management utility — supports both mysqlclient and PyMySQL drivers.
"""
import os
import sys


def main():
    """Run administrative tasks."""
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')

    # ── PyMySQL fallback ──────────────────────────────────────
    # If mysqlclient won't compile, install PyMySQL and uncomment:
    # import pymysql
    # pymysql.install_as_MySQLdb()
    # ─────────────────────────────────────────────────────────

    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Activate your virtual environment "
            "and run:  pip install -r requirements.txt"
        ) from exc

    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()
