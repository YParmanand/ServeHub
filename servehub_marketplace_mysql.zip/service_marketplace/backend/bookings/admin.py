from django.contrib import admin
from .models import Booking

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ['id', 'service', 'receiver', 'status', 'scheduled_date', 'total_price', 'created_at']
    list_filter = ['status', 'scheduled_date']
    search_fields = ['service__title', 'receiver__email']
    readonly_fields = ['created_at', 'updated_at']
