"""
Bookings Views
- Receivers create bookings
- Providers manage (accept/reject/complete)
"""

from rest_framework import generics, status, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db.models import Q
from .models import Booking
from .serializers import BookingSerializer, BookingCreateSerializer, BookingStatusUpdateSerializer


class BookingListCreateView(generics.ListCreateAPIView):
    """
    GET  /api/bookings/ - List user's bookings (provider sees received, receiver sees made)
    POST /api/bookings/ - Create new booking (receiver only)
    """
    permission_classes = [permissions.IsAuthenticated]

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return BookingCreateSerializer
        return BookingSerializer

    def get_queryset(self):
        user = self.request.user
        if user.is_provider:
            # Providers see bookings for their services
            queryset = Booking.objects.filter(
                service__provider=user
            ).select_related('service', 'receiver', 'receiver__receiver_profile')
        else:
            # Receivers see their own bookings
            queryset = Booking.objects.filter(
                receiver=user
            ).select_related('service', 'service__provider', 'service__provider__provider_profile')

        # Optional status filter
        status_filter = self.request.query_params.get('status')
        if status_filter:
            queryset = queryset.filter(status=status_filter)

        return queryset.order_by('-created_at')

    def create(self, request, *args, **kwargs):
        if request.user.is_provider:
            return Response(
                {'error': 'Providers cannot create bookings.'},
                status=status.HTTP_403_FORBIDDEN
            )
        return super().create(request, *args, **kwargs)


class BookingDetailView(generics.RetrieveAPIView):
    """GET /api/bookings/<id>/ - Get booking detail."""
    serializer_class = BookingSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        return Booking.objects.filter(
            Q(receiver=user) | Q(service__provider=user)
        ).select_related('service', 'receiver', 'service__provider')


class BookingStatusView(APIView):
    """
    PATCH /api/bookings/<id>/status/
    Provider updates booking status (accept/reject/complete).
    """
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, pk):
        try:
            booking = Booking.objects.get(pk=pk, service__provider=request.user)
        except Booking.DoesNotExist:
            return Response(
                {'error': 'Booking not found or not authorized.'},
                status=status.HTTP_404_NOT_FOUND
            )

        if not request.user.is_provider:
            return Response(
                {'error': 'Only providers can update booking status.'},
                status=status.HTTP_403_FORBIDDEN
            )

        serializer = BookingStatusUpdateSerializer(booking, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        booking = serializer.save()

        # Update service booking count when completed
        if booking.status == 'completed':
            service = booking.service
            service.total_bookings += 1
            service.save(update_fields=['total_bookings'])
            # Update provider stats
            try:
                profile = booking.service.provider.provider_profile
                profile.total_bookings += 1
                profile.save(update_fields=['total_bookings'])
            except Exception:
                pass

        return Response(BookingSerializer(booking).data)


class CancelBookingView(APIView):
    """
    POST /api/bookings/<id>/cancel/
    Receiver cancels a pending booking.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        try:
            booking = Booking.objects.get(pk=pk, receiver=request.user)
        except Booking.DoesNotExist:
            return Response(
                {'error': 'Booking not found.'},
                status=status.HTTP_404_NOT_FOUND
            )

        if booking.status not in ['pending', 'accepted']:
            return Response(
                {'error': 'Cannot cancel this booking.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        booking.status = 'cancelled'
        booking.save(update_fields=['status'])
        return Response(BookingSerializer(booking).data)


class BookingStatsView(APIView):
    """
    GET /api/bookings/stats/
    Dashboard stats for current user.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        if user.is_provider:
            bookings = Booking.objects.filter(service__provider=user)
            return Response({
                'total': bookings.count(),
                'pending': bookings.filter(status='pending').count(),
                'accepted': bookings.filter(status='accepted').count(),
                'completed': bookings.filter(status='completed').count(),
                'rejected': bookings.filter(status='rejected').count(),
                'total_services': user.services.filter(is_active=True).count(),
            })
        else:
            bookings = Booking.objects.filter(receiver=user)
            return Response({
                'total': bookings.count(),
                'pending': bookings.filter(status='pending').count(),
                'accepted': bookings.filter(status='accepted').count(),
                'completed': bookings.filter(status='completed').count(),
                'cancelled': bookings.filter(status='cancelled').count(),
            })
