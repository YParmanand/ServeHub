"""
Bookings Models
- Booking: Represents a service booking request
"""

from django.db import models


class Booking(models.Model):
    """
    A booking created by a receiver for a provider's service.
    Status flow: pending → accepted/rejected → completed
    """
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    )

    service = models.ForeignKey(
        'services.Service',
        on_delete=models.CASCADE,
        related_name='bookings'
    )
    receiver = models.ForeignKey(
        'accounts.User',
        on_delete=models.CASCADE,
        related_name='my_bookings',
        limit_choices_to={'user_type': 'receiver'}
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    scheduled_date = models.DateField()
    scheduled_time = models.TimeField(blank=True, null=True)
    duration_hours = models.DecimalField(max_digits=4, decimal_places=1, default=1)
    total_price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    message = models.TextField(blank=True, help_text="Message to provider")
    address = models.TextField(blank=True, help_text="Service location/address")
    rejection_reason = models.TextField(blank=True)
    provider_notes = models.TextField(blank=True)
    is_reviewed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'bookings'
        ordering = ['-created_at']

    def __str__(self):
        return f"Booking #{self.id} - {self.service.title} by {self.receiver.email}"

    def save(self, *args, **kwargs):
        # Auto-calculate total price
        if not self.total_price and self.service_id:
            self.total_price = float(self.service.price) * float(self.duration_hours)
        super().save(*args, **kwargs)

    @property
    def provider(self):
        return self.service.provider

    @property
    def can_review(self):
        return self.status == 'completed' and not self.is_reviewed
