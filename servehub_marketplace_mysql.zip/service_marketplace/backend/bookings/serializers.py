"""
Bookings Serializers
"""

from rest_framework import serializers
from .models import Booking
from services.serializers import ServiceListSerializer
from accounts.serializers import UserSerializer


class BookingCreateSerializer(serializers.ModelSerializer):
    """For creating a new booking."""
    class Meta:
        model = Booking
        fields = [
            'id', 'service', 'scheduled_date', 'scheduled_time',
            'duration_hours', 'message', 'address'
        ]

    def validate_service(self, service):
        if not service.is_active:
            raise serializers.ValidationError("This service is not available.")
        if service.availability == 'unavailable':
            raise serializers.ValidationError("Provider is unavailable.")
        # Prevent providers from booking their own service
        request = self.context.get('request')
        if request and service.provider == request.user:
            raise serializers.ValidationError("You cannot book your own service.")
        return service

    def create(self, validated_data):
        validated_data['receiver'] = self.context['request'].user
        service = validated_data['service']
        duration = validated_data.get('duration_hours', 1)
        validated_data['total_price'] = float(service.price) * float(duration)
        return super().create(validated_data)


class BookingSerializer(serializers.ModelSerializer):
    """Full booking serializer with nested service and users."""
    service = ServiceListSerializer(read_only=True)
    receiver = UserSerializer(read_only=True)
    provider_name = serializers.SerializerMethodField()
    can_review = serializers.BooleanField(read_only=True)

    class Meta:
        model = Booking
        fields = [
            'id', 'service', 'receiver', 'provider_name',
            'status', 'scheduled_date', 'scheduled_time',
            'duration_hours', 'total_price',
            'message', 'address', 'rejection_reason',
            'provider_notes', 'is_reviewed', 'can_review',
            'created_at', 'updated_at'
        ]

    def get_provider_name(self, obj):
        provider = obj.service.provider
        return provider.get_full_name() or provider.username


class BookingStatusUpdateSerializer(serializers.ModelSerializer):
    """For provider to accept/reject/complete."""
    class Meta:
        model = Booking
        fields = ['status', 'rejection_reason', 'provider_notes']

    def validate_status(self, value):
        allowed = ['accepted', 'rejected', 'completed']
        if value not in allowed:
            raise serializers.ValidationError(
                f"Status must be one of: {', '.join(allowed)}"
            )
        return value
