#!/bin/bash
# ================================================================
#  ServeHub Service Marketplace — MySQL Setup Script
#  Database: service_db | User: root | Password: parma123
# ================================================================
set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}  ╔══════════════════════════════════════════╗${NC}"
echo -e "${CYAN}  ║   ServeHub — Service Marketplace Setup   ║${NC}"
echo -e "${CYAN}  ║   MySQL Database: service_db              ║${NC}"
echo -e "${CYAN}  ╚══════════════════════════════════════════╝${NC}"
echo ""

# ── Step 1: Create MySQL database ────────────────────────────
echo -e "${YELLOW}[1/6] Creating MySQL database 'service_db'...${NC}"
mysql -u root -pparma123 -e "
  CREATE DATABASE IF NOT EXISTS service_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
" 2>/dev/null && echo -e "  ${GREEN}✓ Database ready${NC}" \
              || echo -e "  ${YELLOW}⚠ Auto-create failed — create manually:${NC}
       mysql -u root -pparma123 -e \"CREATE DATABASE service_db CHARACTER SET utf8mb4;\""

echo ""

# ── Step 2: Virtual environment ───────────────────────────────
echo -e "${YELLOW}[2/6] Virtual environment...${NC}"
[ ! -d "venv" ] && python3 -m venv venv && echo -e "  ${GREEN}✓ Created venv${NC}" \
                || echo -e "  ${GREEN}✓ venv exists${NC}"
source venv/bin/activate

# ── Step 3: Install dependencies ─────────────────────────────
echo ""
echo -e "${YELLOW}[3/6] Installing Python packages...${NC}"
pip install -q Django==4.2.9 djangorestframework==3.14.0 \
    djangorestframework-simplejwt==5.3.1 django-cors-headers==4.3.1 \
    Pillow==10.2.0 python-decouple==3.8 gunicorn==21.2.0 whitenoise==6.6.0

echo -e "  ${CYAN}→ Installing MySQL driver (mysqlclient)...${NC}"
pip install -q mysqlclient 2>/dev/null && echo -e "  ${GREEN}✓ mysqlclient installed${NC}" || {
    echo -e "  ${YELLOW}⚠ Trying PyMySQL fallback...${NC}"
    pip install -q PyMySQL
    # Auto-enable PyMySQL in both entry points
    sed -i 's/# import pymysql/import pymysql/' manage.py
    sed -i 's/# pymysql.install_as_MySQLdb()/pymysql.install_as_MySQLdb()/' manage.py
    sed -i 's/# import pymysql/import pymysql/' core/wsgi.py
    sed -i 's/# pymysql.install_as_MySQLdb()/pymysql.install_as_MySQLdb()/' core/wsgi.py
    echo -e "  ${GREEN}✓ PyMySQL installed and activated${NC}"
}

# ── Step 4: Migrations ────────────────────────────────────────
echo ""
echo -e "${YELLOW}[4/6] Creating all database tables...${NC}"
python manage.py makemigrations accounts services bookings reviews
python manage.py migrate
echo -e "  ${GREEN}✓ All tables created in service_db${NC}"

# ── Step 5: Seed data ─────────────────────────────────────────
echo ""
echo -e "${YELLOW}[5/6] Seeding categories + demo users...${NC}"
python manage.py seed_data --demo

# ── Step 6: Superuser ─────────────────────────────────────────
echo ""
echo -e "${YELLOW}[6/6] Creating admin superuser...${NC}"
python manage.py shell -c "
from accounts.models import User
if not User.objects.filter(email='admin@servehub.com').exists():
    User.objects.create_superuser('admin', 'admin@servehub.com', 'Admin@12345')
    print('  Created: admin@servehub.com')
else:
    print('  Already exists: admin@servehub.com')
"

# ── Summary ───────────────────────────────────────────────────
echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  ✅  Setup complete!${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "  ${CYAN}Start:${NC}   python manage.py runserver"
echo -e "  ${CYAN}App:${NC}     http://127.0.0.1:8000"
echo -e "  ${CYAN}Admin:${NC}   http://127.0.0.1:8000/admin"
echo -e "  ${CYAN}API:${NC}     http://127.0.0.1:8000/api/"
echo ""
echo "  Demo accounts (password: Demo@12345)"
echo "  ┌────────────────────────────────┬──────────┐"
echo "  │ john.teacher@demo.com          │ Provider │"
echo "  │ sarah.trainer@demo.com         │ Provider │"
echo "  │ raj.developer@demo.com         │ Provider │"
echo "  │ alice@demo.com                 │ Receiver │"
echo "  │ admin@servehub.com (Admin@12345)│ Admin   │"
echo "  └────────────────────────────────┴──────────┘"
echo ""
echo "  MySQL: localhost:3306 | DB: service_db | User: root"
echo ""
