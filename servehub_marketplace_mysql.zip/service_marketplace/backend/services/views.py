"""
Services Views
CRUD for services with filtering and search
"""

from rest_framework import generics, filters, status, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db.models import Q
from .models import Service, ServiceCategory
from .serializers import (
    ServiceListSerializer, ServiceDetailSerializer,
    ServiceCreateUpdateSerializer, ServiceCategorySerializer
)
from .permissions import IsProviderOrReadOnly, IsServiceOwner


class ServiceCategoryListView(generics.ListAPIView):
    """GET /api/services/categories/ - List all active categories."""
    queryset = ServiceCategory.objects.filter(is_active=True)
    serializer_class = ServiceCategorySerializer
    permission_classes = [permissions.AllowAny]


class ServiceListCreateView(generics.ListCreateAPIView):
    """
    GET  /api/services/          - Public list with search/filter
    POST /api/services/          - Create service (provider only)
    """
    permission_classes = [IsProviderOrReadOnly]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['title', 'description', 'tags', 'location']
    ordering_fields = ['price', 'rating', 'created_at', 'total_bookings']
    ordering = ['-created_at']

    def get_queryset(self):
        queryset = Service.objects.filter(is_active=True).select_related(
            'provider', 'provider__provider_profile', 'category'
        )

        # Filter params
        category = self.request.query_params.get('category')
        city = self.request.query_params.get('city')
        min_price = self.request.query_params.get('min_price')
        max_price = self.request.query_params.get('max_price')
        availability = self.request.query_params.get('availability')
        provider_id = self.request.query_params.get('provider')

        if category:
            queryset = queryset.filter(
                Q(category__slug=category) | Q(category__id=category)
            )
        if city:
            queryset = queryset.filter(city__icontains=city)
        if min_price:
            queryset = queryset.filter(price__gte=min_price)
        if max_price:
            queryset = queryset.filter(price__lte=max_price)
        if availability:
            queryset = queryset.filter(availability=availability)
        if provider_id:
            queryset = queryset.filter(provider_id=provider_id)

        return queryset

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ServiceCreateUpdateSerializer
        return ServiceListSerializer


class ServiceDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    GET    /api/services/<id>/ - Public detail view
    PUT    /api/services/<id>/ - Update (owner only)
    DELETE /api/services/<id>/ - Delete (owner only)
    """
    queryset = Service.objects.select_related('provider', 'provider__provider_profile', 'category')

    def get_permissions(self):
        if self.request.method == 'GET':
            return [permissions.AllowAny()]
        return [IsServiceOwner()]

    def get_serializer_class(self):
        if self.request.method == 'GET':
            return ServiceDetailSerializer
        return ServiceCreateUpdateSerializer


class MyServicesView(generics.ListAPIView):
    """
    GET /api/services/my-services/ - Provider's own services
    """
    serializer_class = ServiceListSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Service.objects.filter(
            provider=self.request.user
        ).select_related('category')

    def get(self, request, *args, **kwargs):
        if not request.user.is_provider:
            return Response(
                {'error': 'Only providers can access this.'},
                status=status.HTTP_403_FORBIDDEN
            )
        return super().get(request, *args, **kwargs)


class FeaturedServicesView(generics.ListAPIView):
    """GET /api/services/featured/ - Top-rated services."""
    serializer_class = ServiceListSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        return Service.objects.filter(
            is_active=True, availability='available'
        ).order_by('-rating', '-total_bookings')[:8]
