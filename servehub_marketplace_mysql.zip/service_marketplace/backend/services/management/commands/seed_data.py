"""
Management command to seed the database with initial categories and demo data.
Run: python manage.py seed_data
"""

from django.core.management.base import BaseCommand
from services.models import ServiceCategory
from accounts.models import User, ProviderProfile, ReceiverProfile
from services.models import Service
from bookings.models import Booking
from datetime import date, timedelta
import random


CATEGORIES = [
    {'name': 'Teaching & Tutoring', 'slug': 'teaching', 'icon': '🎓', 'description': 'Academic tutoring, language lessons, skill teaching'},
    {'name': 'Medical & Healthcare', 'slug': 'medical', 'icon': '🏥', 'description': 'Doctors, nurses, therapists, wellness experts'},
    {'name': 'Home Repair & Maintenance', 'slug': 'home', 'icon': '🏠', 'description': 'Plumbers, electricians, carpenters, cleaners'},
    {'name': 'Fitness & Training', 'slug': 'fitness', 'icon': '💪', 'description': 'Personal trainers, yoga instructors, nutritionists'},
    {'name': 'Technology & IT', 'slug': 'tech', 'icon': '💻', 'description': 'Web developers, IT support, software engineers'},
    {'name': 'Beauty & Wellness', 'slug': 'beauty', 'icon': '💇', 'description': 'Hair stylists, makeup artists, massage therapists'},
    {'name': 'Legal & Finance', 'slug': 'legal', 'icon': '⚖️', 'description': 'Lawyers, accountants, financial advisors'},
    {'name': 'Transport & Delivery', 'slug': 'transport', 'icon': '🚗', 'description': 'Drivers, movers, couriers'},
    {'name': 'Events & Photography', 'slug': 'event', 'icon': '🎉', 'description': 'Event planners, photographers, videographers'},
    {'name': 'Other Services', 'slug': 'other', 'icon': '🔧', 'description': 'Any other professional service'},
]


class Command(BaseCommand):
    help = 'Seed database with initial categories and demo data'

    def add_arguments(self, parser):
        parser.add_argument('--demo', action='store_true', help='Also create demo users and services')

    def handle(self, *args, **options):
        # Create categories
        self.stdout.write('Creating service categories...')
        for cat_data in CATEGORIES:
            cat, created = ServiceCategory.objects.get_or_create(
                slug=cat_data['slug'],
                defaults=cat_data
            )
            if created:
                self.stdout.write(f'  ✓ Created: {cat.name}')
            else:
                self.stdout.write(f'  - Exists: {cat.name}')

        if options['demo']:
            self.create_demo_data()

        self.stdout.write(self.style.SUCCESS('\n✅ Seeding complete!'))

    def create_demo_data(self):
        self.stdout.write('\nCreating demo users...')

        # Create demo providers
        providers_data = [
            {
                'email': 'john.teacher@demo.com', 'username': 'john_teacher',
                'first_name': 'John', 'last_name': 'Smith',
                'skills': 'Mathematics, Physics, Chemistry',
                'experience_years': 8, 'hourly_rate': 500,
                'city': 'Hyderabad', 'bio': 'Experienced math and science tutor with 8 years of teaching experience.',
                'service_category': 'teaching',
                'service_title': 'Expert Math & Science Tutoring',
                'service_desc': 'One-on-one tutoring sessions for students from class 6 to 12. Specializing in Mathematics and Science.',
                'service_price': 500,
            },
            {
                'email': 'sarah.trainer@demo.com', 'username': 'sarah_trainer',
                'first_name': 'Sarah', 'last_name': 'Johnson',
                'skills': 'Yoga, Pilates, Nutrition, Weight Loss',
                'experience_years': 5, 'hourly_rate': 800,
                'city': 'Mumbai', 'bio': 'Certified personal trainer helping clients achieve their fitness goals.',
                'service_category': 'fitness',
                'service_title': 'Personal Fitness Training',
                'service_desc': 'Custom workout plans, nutrition guidance, and one-on-one training sessions.',
                'service_price': 800,
            },
            {
                'email': 'raj.developer@demo.com', 'username': 'raj_dev',
                'first_name': 'Raj', 'last_name': 'Kumar',
                'skills': 'Python, Django, React, JavaScript, PostgreSQL',
                'experience_years': 6, 'hourly_rate': 1500,
                'city': 'Bangalore', 'bio': 'Full-stack developer specializing in Django and React applications.',
                'service_category': 'tech',
                'service_title': 'Full-Stack Web Development',
                'service_desc': 'Building responsive web applications with Python/Django backend and React frontend.',
                'service_price': 1500,
            },
        ]

        for pd in providers_data:
            if not User.objects.filter(email=pd['email']).exists():
                user = User.objects.create_user(
                    email=pd['email'], username=pd['username'],
                    first_name=pd['first_name'], last_name=pd['last_name'],
                    password='Demo@12345', user_type='provider'
                )
                ProviderProfile.objects.create(
                    user=user, skills=pd['skills'],
                    experience_years=pd['experience_years'],
                    hourly_rate=pd['hourly_rate'],
                    city=pd['city'], bio=pd['bio'],
                    country='India', is_available=True,
                )
                cat = ServiceCategory.objects.get(slug=pd['service_category'])
                Service.objects.create(
                    provider=user, category=cat,
                    title=pd['service_title'],
                    description=pd['service_desc'],
                    price=pd['service_price'],
                    location=pd['city'],
                    city=pd['city'],
                    availability='available',
                )
                self.stdout.write(f"  ✓ Provider: {user.email}")

        # Create demo receiver
        if not User.objects.filter(email='alice@demo.com').exists():
            receiver = User.objects.create_user(
                email='alice@demo.com', username='alice_receiver',
                first_name='Alice', last_name='Fernandez',
                password='Demo@12345', user_type='receiver'
            )
            ReceiverProfile.objects.create(
                user=receiver, city='Hyderabad', country='India',
                address='123, MG Road, Hyderabad'
            )
            self.stdout.write(f"  ✓ Receiver: {receiver.email}")

        self.stdout.write('\nDemo credentials:')
        self.stdout.write('  Provider: john.teacher@demo.com / Demo@12345')
        self.stdout.write('  Receiver: alice@demo.com / Demo@12345')
