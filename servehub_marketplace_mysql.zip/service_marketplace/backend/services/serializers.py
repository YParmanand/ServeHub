"""
Services Serializers
"""

from rest_framework import serializers
from .models import Service, ServiceCategory
from accounts.serializers import UserSerializer


class ServiceCategorySerializer(serializers.ModelSerializer):
    service_count = serializers.SerializerMethodField()

    class Meta:
        model = ServiceCategory
        fields = ['id', 'name', 'slug', 'description', 'icon', 'service_count']

    def get_service_count(self, obj):
        return obj.services.filter(is_active=True).count()


class ServiceListSerializer(serializers.ModelSerializer):
    """Lightweight serializer for list views."""
    category_name = serializers.CharField(source='category.name', read_only=True)
    category_icon = serializers.CharField(source='category.icon', read_only=True)
    provider_name = serializers.SerializerMethodField()
    provider_image = serializers.SerializerMethodField()

    class Meta:
        model = Service
        fields = [
            'id', 'title', 'description', 'price', 'price_type',
            'location', 'city', 'availability', 'image',
            'category_name', 'category_icon',
            'provider_name', 'provider_image',
            'total_bookings', 'rating', 'total_reviews',
            'is_active', 'created_at'
        ]

    def get_provider_name(self, obj):
        return obj.provider.get_full_name() or obj.provider.username

    def get_provider_image(self, obj):
        try:
            profile = obj.provider.provider_profile
            if profile.profile_image:
                request = self.context.get('request')
                if request:
                    return request.build_absolute_uri(profile.profile_image.url)
        except Exception:
            pass
        return None


class ServiceDetailSerializer(serializers.ModelSerializer):
    """Full serializer with provider info for detail view."""
    category = ServiceCategorySerializer(read_only=True)
    category_id = serializers.PrimaryKeyRelatedField(
        queryset=ServiceCategory.objects.all(),
        source='category',
        write_only=True
    )
    provider = UserSerializer(read_only=True)

    class Meta:
        model = Service
        fields = [
            'id', 'title', 'description', 'price', 'price_type',
            'location', 'city', 'availability', 'image', 'tags',
            'category', 'category_id', 'provider',
            'total_bookings', 'rating', 'total_reviews',
            'is_active', 'created_at', 'updated_at'
        ]
        read_only_fields = ['provider', 'total_bookings', 'rating', 'total_reviews']

    def create(self, validated_data):
        validated_data['provider'] = self.context['request'].user
        return super().create(validated_data)


class ServiceCreateUpdateSerializer(serializers.ModelSerializer):
    """Serializer for creating/updating services."""
    class Meta:
        model = Service
        fields = [
            'id', 'title', 'description', 'price', 'price_type',
            'location', 'city', 'availability', 'image', 'tags',
            'category', 'is_active'
        ]

    def create(self, validated_data):
        validated_data['provider'] = self.context['request'].user
        return super().create(validated_data)
