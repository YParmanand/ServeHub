"""
Custom Permissions for Services
"""

from rest_framework import permissions


class IsProviderOrReadOnly(permissions.BasePermission):
    """Allow read-only for anyone, write only for providers."""

    def has_permission(self, request, view):
        if request.method in permissions.SAFE_METHODS:
            return True
        return (
            request.user and
            request.user.is_authenticated and
            request.user.is_provider
        )


class IsServiceOwner(permissions.BasePermission):
    """Only the service owner can modify it."""

    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated

    def has_object_permission(self, request, view, obj):
        return obj.provider == request.user


class IsBookingParticipant(permissions.BasePermission):
    """Allow access only to the provider or receiver of a booking."""

    def has_object_permission(self, request, view, obj):
        return (
            obj.receiver == request.user or
            obj.service.provider == request.user
        )
