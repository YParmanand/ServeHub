from django.contrib import admin
from .models import Service, ServiceCategory

@admin.register(ServiceCategory)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug', 'icon', 'is_active']
    prepopulated_fields = {'slug': ('name',)}

@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ['title', 'provider', 'category', 'price', 'availability', 'rating', 'is_active']
    list_filter = ['availability', 'category', 'is_active']
    search_fields = ['title', 'provider__email', 'location']
