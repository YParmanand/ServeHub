"""
Services Models
- Service: What providers offer
- ServiceCategory: Organized categories
"""

from django.db import models
from django.core.validators import MinValueValidator


class ServiceCategory(models.Model):
    """
    Predefined service categories (Teaching, Medical, Home Repair, etc.)
    """
    CATEGORY_ICONS = {
        'teaching': '🎓',
        'medical': '🏥',
        'home': '🏠',
        'fitness': '💪',
        'tech': '💻',
        'beauty': '💇',
        'legal': '⚖️',
        'finance': '💰',
        'transport': '🚗',
        'event': '🎉',
        'other': '🔧',
    }

    name = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(unique=True)
    description = models.TextField(blank=True)
    icon = models.CharField(max_length=10, default='🔧')
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'service_categories'
        verbose_name_plural = 'Service Categories'
        ordering = ['name']

    def __str__(self):
        return self.name


class Service(models.Model):
    """
    A service offered by a provider.
    Includes pricing, location, availability.
    """
    AVAILABILITY_CHOICES = (
        ('available', 'Available'),
        ('busy', 'Busy'),
        ('unavailable', 'Unavailable'),
    )

    provider = models.ForeignKey(
        'accounts.User',
        on_delete=models.CASCADE,
        related_name='services',
        limit_choices_to={'user_type': 'provider'}
    )
    category = models.ForeignKey(
        ServiceCategory,
        on_delete=models.SET_NULL,
        null=True,
        related_name='services'
    )
    title = models.CharField(max_length=200)
    description = models.TextField()
    price = models.DecimalField(
        max_digits=10, decimal_places=2,
        validators=[MinValueValidator(0)]
    )
    price_type = models.CharField(
        max_length=20,
        choices=[('hourly', 'Per Hour'), ('fixed', 'Fixed Price'), ('daily', 'Per Day')],
        default='hourly'
    )
    location = models.CharField(max_length=200)
    city = models.CharField(max_length=100, blank=True)
    availability = models.CharField(
        max_length=20, choices=AVAILABILITY_CHOICES, default='available'
    )
    image = models.ImageField(upload_to='services/', blank=True, null=True)
    tags = models.CharField(max_length=300, blank=True, help_text="Comma-separated tags")
    is_active = models.BooleanField(default=True)
    total_bookings = models.PositiveIntegerField(default=0)
    rating = models.DecimalField(max_digits=3, decimal_places=2, default=0)
    total_reviews = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'services'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.title} by {self.provider.email}"

    def update_rating(self):
        """Recalculate average rating from all reviews."""
        from reviews.models import Review
        reviews = Review.objects.filter(service=self)
        if reviews.exists():
            total = sum(r.rating for r in reviews)
            self.rating = round(total / reviews.count(), 2)
            self.total_reviews = reviews.count()
            self.save(update_fields=['rating', 'total_reviews'])
