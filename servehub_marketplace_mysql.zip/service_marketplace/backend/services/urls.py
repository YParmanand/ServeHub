from django.urls import path
from . import views

urlpatterns = [
    path('', views.ServiceListCreateView.as_view(), name='service-list-create'),
    path('categories/', views.ServiceCategoryListView.as_view(), name='category-list'),
    path('featured/', views.FeaturedServicesView.as_view(), name='featured-services'),
    path('my-services/', views.MyServicesView.as_view(), name='my-services'),
    path('<int:pk>/', views.ServiceDetailView.as_view(), name='service-detail'),
]
