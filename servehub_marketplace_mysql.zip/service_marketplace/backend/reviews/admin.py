from django.contrib import admin
from .models import Review

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ['service', 'reviewer', 'rating', 'is_visible', 'created_at']
    list_filter = ['rating', 'is_visible']
    search_fields = ['service__title', 'reviewer__email', 'comment']
