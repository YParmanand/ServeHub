"""
Reviews Models
- Review: Rating and comment for a completed service booking
"""

from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator


class Review(models.Model):
    """
    A review left by a receiver after service completion.
    One review per completed booking.
    """
    service = models.ForeignKey(
        'services.Service',
        on_delete=models.CASCADE,
        related_name='reviews'
    )
    booking = models.OneToOneField(
        'bookings.Booking',
        on_delete=models.CASCADE,
        related_name='review'
    )
    reviewer = models.ForeignKey(
        'accounts.User',
        on_delete=models.CASCADE,
        related_name='given_reviews',
        limit_choices_to={'user_type': 'receiver'}
    )
    rating = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)]
    )
    comment = models.TextField()
    is_visible = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'reviews'
        ordering = ['-created_at']
        unique_together = ['booking', 'reviewer']

    def __str__(self):
        return f"Review by {self.reviewer.email} for {self.service.title} ({self.rating}★)"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        # Update service rating after save
        self.service.update_rating()
        # Update provider rating
        try:
            self.service.provider.provider_profile.update_rating()
        except Exception:
            pass
