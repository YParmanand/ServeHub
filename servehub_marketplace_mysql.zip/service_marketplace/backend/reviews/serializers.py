"""
Reviews Serializers
"""

from rest_framework import serializers
from .models import Review
from accounts.serializers import UserSerializer


class ReviewSerializer(serializers.ModelSerializer):
    reviewer = UserSerializer(read_only=True)
    reviewer_name = serializers.SerializerMethodField()

    class Meta:
        model = Review
        fields = [
            'id', 'service', 'booking', 'reviewer', 'reviewer_name',
            'rating', 'comment', 'created_at'
        ]
        read_only_fields = ['reviewer', 'service']

    def get_reviewer_name(self, obj):
        return obj.reviewer.get_full_name() or obj.reviewer.username


class ReviewCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Review
        fields = ['booking', 'rating', 'comment']

    def validate_booking(self, booking):
        request = self.context.get('request')
        if booking.receiver != request.user:
            raise serializers.ValidationError("This is not your booking.")
        if booking.status != 'completed':
            raise serializers.ValidationError("Can only review completed bookings.")
        if booking.is_reviewed:
            raise serializers.ValidationError("You have already reviewed this booking.")
        return booking

    def create(self, validated_data):
        booking = validated_data['booking']
        validated_data['reviewer'] = self.context['request'].user
        validated_data['service'] = booking.service
        review = super().create(validated_data)
        # Mark booking as reviewed
        booking.is_reviewed = True
        booking.save(update_fields=['is_reviewed'])
        return review
