"""
Reviews Views
"""

from rest_framework import generics, permissions, status
from rest_framework.response import Response
from .models import Review
from .serializers import ReviewSerializer, ReviewCreateSerializer


class ReviewListView(generics.ListAPIView):
    """GET /api/reviews/?service=<id> - List reviews for a service."""
    serializer_class = ReviewSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        queryset = Review.objects.filter(is_visible=True).select_related('reviewer')
        service_id = self.request.query_params.get('service')
        if service_id:
            queryset = queryset.filter(service_id=service_id)
        return queryset


class ReviewCreateView(generics.CreateAPIView):
    """POST /api/reviews/ - Create a review (receiver only)."""
    serializer_class = ReviewCreateSerializer
    permission_classes = [permissions.IsAuthenticated]

    def create(self, request, *args, **kwargs):
        if request.user.is_provider:
            return Response(
                {'error': 'Providers cannot leave reviews.'},
                status=status.HTTP_403_FORBIDDEN
            )
        return super().create(request, *args, **kwargs)


class MyReviewsView(generics.ListAPIView):
    """GET /api/reviews/my-reviews/ - Reviews given by current user."""
    serializer_class = ReviewSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Review.objects.filter(reviewer=self.request.user).select_related('service')
