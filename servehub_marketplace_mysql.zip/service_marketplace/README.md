# 🛠️ ServeHub — Service Marketplace (MySQL Edition)

Production-ready service marketplace built with **Django REST Framework + MySQL** backend and **Bootstrap 5 + Vanilla JS** frontend.

---

## 📁 Project Structure

```
service_marketplace/
├── backend/
│   ├── core/
│   │   ├── settings.py          ← MySQL: service_db / root / parma123
│   │   ├── urls.py
│   │   └── wsgi.py
│   ├── accounts/                ← Custom User, ProviderProfile, ReceiverProfile
│   ├── services/                ← Service, ServiceCategory + search/filter
│   ├── bookings/                ← Booking status flow + stats
│   ├── reviews/                 ← Reviews + auto rating updates
│   ├── templates/
│   │   └── index.html           ← Full SPA frontend
│   ├── manage.py
│   ├── requirements.txt
│   ├── mysql_init.sql           ← Run this FIRST
│   └── setup.sh                 ← One-command automated setup
├── demo.html                    ← Standalone interactive demo
└── README.md
```

---

## 🗄️ MySQL Configuration (Already Set)

`core/settings.py` is pre-configured with your credentials:

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME':     'service_db',
        'USER':     'root',
        'PASSWORD': 'parma123',
        'HOST':     'localhost',
        'PORT':     '3306',
        'OPTIONS': {
            'charset': 'utf8mb4',
            'init_command': "SET sql_mode='STRICT_TRANS_TABLES'",
        },
    }
}
```

---

## 🚀 Setup — Option A: One Command

```bash
cd service_marketplace/backend
chmod +x setup.sh
./setup.sh
```

Automatically: creates DB → installs packages → migrates → seeds data → creates admin.

---

## 🚀 Setup — Option B: Manual

### Step 1 — Create the database
```bash
mysql -u root -pparma123 < mysql_init.sql
```
Or manually in MySQL shell:
```sql
CREATE DATABASE service_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### Step 2 — Virtual environment
```bash
python3 -m venv venv
source venv/bin/activate        # Linux/Mac
venv\Scripts\activate           # Windows
```

### Step 3 — Install dependencies
```bash
pip install -r requirements.txt
```

> **If mysqlclient fails** → use PyMySQL instead:
> ```bash
> pip install PyMySQL
> ```
> Then uncomment in `manage.py` **and** `core/wsgi.py`:
> ```python
> import pymysql
> pymysql.install_as_MySQLdb()
> ```

### Step 4 — Migrate (creates all MySQL tables)
```bash
python manage.py makemigrations accounts services bookings reviews
python manage.py migrate
```

### Step 5 — Seed data
```bash
python manage.py seed_data --demo
```

### Step 6 — Create admin
```bash
python manage.py createsuperuser
```

### Step 7 — Run
```bash
python manage.py runserver
```

---

## 🔗 URLs

| URL | Description |
|---|---|
| `http://127.0.0.1:8000` | Frontend SPA |
| `http://127.0.0.1:8000/admin` | Django admin panel |
| `http://127.0.0.1:8000/api/` | REST API |

---

## 🔑 Demo Credentials (after `seed_data --demo`)

| Email | Password | Role |
|---|---|---|
| john.teacher@demo.com | Demo@12345 | Provider |
| sarah.trainer@demo.com | Demo@12345 | Provider |
| raj.developer@demo.com | Demo@12345 | Provider |
| alice@demo.com | Demo@12345 | Receiver |
| admin@servehub.com | Admin@12345 | Superuser |

---

## 📡 API Endpoints

### Accounts
| Method | Endpoint | Auth |
|---|---|---|
| POST | `/api/accounts/register/` | Public |
| POST | `/api/accounts/login/` | Public |
| POST | `/api/accounts/logout/` | Required |
| POST | `/api/accounts/token/refresh/` | Public |
| GET/PUT | `/api/accounts/me/` | Required |
| GET/PUT | `/api/accounts/provider-profile/` | Provider |
| GET/PUT | `/api/accounts/receiver-profile/` | Receiver |
| POST | `/api/accounts/change-password/` | Required |

### Services
| Method | Endpoint | Auth |
|---|---|---|
| GET | `/api/services/` | Public |
| POST | `/api/services/` | Provider |
| GET | `/api/services/<id>/` | Public |
| PUT/DELETE | `/api/services/<id>/` | Owner |
| GET | `/api/services/categories/` | Public |
| GET | `/api/services/featured/` | Public |
| GET | `/api/services/my-services/` | Provider |

**Search & Filter params:** `?search=` `?category=` `?city=` `?min_price=` `?max_price=` `?availability=` `?ordering=`

### Bookings
| Method | Endpoint | Auth |
|---|---|---|
| GET/POST | `/api/bookings/` | Required |
| GET | `/api/bookings/<id>/` | Participant |
| PATCH | `/api/bookings/<id>/status/` | Provider |
| POST | `/api/bookings/<id>/cancel/` | Receiver |
| GET | `/api/bookings/stats/` | Required |

### Reviews
| Method | Endpoint | Auth |
|---|---|---|
| GET | `/api/reviews/?service=<id>` | Public |
| POST | `/api/reviews/create/` | Receiver |
| GET | `/api/reviews/my-reviews/` | Required |

---

## 📊 MySQL Tables Created by Django

```
service_db/
├── users                    (accounts_user — custom AbstractUser)
├── provider_profiles        (accounts_providerprofile)
├── receiver_profiles        (accounts_receiverprofile)
├── service_categories       (services_servicecategory)
├── services                 (services_service)
├── bookings                 (bookings_booking)
├── reviews                  (reviews_review)
├── outstanding_token        (JWT tokens)
├── blacklisted_token        (JWT blacklist)
├── django_admin_log
├── django_content_type
├── django_migrations
├── django_session
└── auth_*
```

---

## 🛠️ MySQL Driver Troubleshooting

| Issue | Fix |
|---|---|
| `mysqlclient` fails on Linux | `sudo apt install python3-dev default-libmysqlclient-dev build-essential` |
| `mysqlclient` fails on Mac | `brew install mysql-client && export PKG_CONFIG_PATH="$(brew --prefix)/opt/mysql-client/lib/pkgconfig"` |
| `mysqlclient` fails on Windows | Use PyMySQL: `pip install PyMySQL` then uncomment 2 lines in `manage.py` |
| "Access denied" | Check MySQL is running: `mysql -u root -pparma123 -e "SELECT 1"` |
| "Unknown database" | Run `mysql_init.sql` first |

---

## 🌍 Production Notes

1. Change `SECRET_KEY` and set `DEBUG = False`
2. Use a dedicated MySQL user (not root):
   ```sql
   CREATE USER 'servehub'@'localhost' IDENTIFIED BY 'strongpass';
   GRANT ALL ON service_db.* TO 'servehub'@'localhost';
   ```
3. Run `python manage.py collectstatic`
4. Use Gunicorn: `gunicorn core.wsgi:application --bind 0.0.0.0:8000`

---
Built with Django 4.2 + MySQL 8 + Bootstrap 5
